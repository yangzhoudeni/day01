# 三目运算符

# 条件 ? 真值 : 假值

# python坚持 语义化特点:  外国人习惯倒装语法
# 真值 if 条件真 else 假值

married = False

print('已婚' if married else '未婚')
