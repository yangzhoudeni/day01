# 逻辑运算符
'''
        大多数语言   python(语义化)
逻辑与    &&         and
逻辑或    ||         or
逻辑非    !          not
'''

# 逻辑与: 都真则真,有假为假
print(True and True)
print(True and False)

# 逻辑或: 都假则假,有真则真
print(True or False)
print(False or False)

# 逻辑非: 非真为假,非假为真
print(not False)
print(not True)
