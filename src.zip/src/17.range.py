# range 函数

a = range(10)  # 10个数字, 从0开始
print(list(a))

a = range(10, 20)  # 含头不含尾 10~19 没20
print(list(a))

a = range(10, 20, 2)  # 参数3: 步长
print(list(a))
